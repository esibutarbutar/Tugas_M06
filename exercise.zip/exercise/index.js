import express from 'express';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

const app = express()
const hostname = '127.0.0.1'
const port = 3000

app.use(express.static('public'))

app.get('(/home)?', (req, res)=>{
    res.sendFile(__dirname + '/page/home.html')
})

app.get('/product', (req, res)=>{
    res.sendFile(__dirname + '/page/product.html')
})

app.get('/about', (req, res) => {
    res.sendFile(__dirname + '/page/about.html')
})

app.get('/product(/:nama)?', (req, res) => {
    const nama = req.params.nama
    res.send(`<h1>Product Name : ${nama}</h1>`)
})


app.listen(port, () => {
    console.log(`Server running at http://${hostname}:${port}`);
})
